#!/usr/bin/env python3
import sys
import Adafruit_DHT
from time import sleep
from SX127x.LoRa import *
from SX127x.LoRaArgumentParser import LoRaArgumentParser
from SX127x.board_config import BOARD
import LoRaWAN
from LoRaWAN.MHDR import MHDR
import json,datetime
import smtplib
import random
import pymysql
zUser = ''
zPass = ''
zTo = ''
zFrom = zUser

BOARD.setup()
parser = LoRaArgumentParser("LoRaWAN sender")

class LoRaWANsend(LoRa):
    def __init__(self, devaddr = [], nwkey = [], appkey = [], verbose = False):
        super(LoRaWANsend, self).__init__(verbose)
        
    def on_tx_done(self):
        print("TxDone\n")
        # 切換到rx
        self.set_mode(MODE.STDBY)
        self.clear_irq_flags(TxDone=1)
        self.set_mode(MODE.SLEEP)
        self.set_dio_mapping([0,0,0,0,0,0])
        self.set_invert_iq(1)
        self.reset_ptr_rx()
        sleep(1)
        self.set_mode(MODE.RXSINGLE)
        
    def on_rx_done(self):
        global RxDone
        RxDone = any([self.get_irq_flags()[s] for s in ['rx_done']])
        print("RxDone")
        self.clear_irq_flags(RxDone=1)
        
        # 讀取 payload
        payload = self.read_payload(nocheck=True)
        lorawan = LoRaWAN.new(nwskey, appskey)
        lorawan.read(payload)
        print("get mic: ",lorawan.get_mic())
        print("compute mic: ",lorawan.compute_mic())
        print("valid mic: ",lorawan.valid_mic())
        # 檢查mic
        if lorawan.valid_mic():
            print("ACK: ",lorawan.get_mac_payload().get_fhdr().get_fctrl()>>5&0x01)
            print("direction: ",lorawan.get_direction())
            print("devaddr: ",''.join(format(x, '02x') for x in lorawan.get_devaddr()))
            write_config()
        else:
            print("Wrong MIC")
    
    def send(self):
        global fCnt
        lorawan = LoRaWAN.new(nwskey, appskey)
        #message = "{\n\t\"Humidity\":{1:0.1f}%,\n\t\"Status\":\"success\",\n\t\"Temp\":\"{0:0.1f}*\"\n}".format(humidity, temperature)
        #message = "{\n\t\"Humidity\":{1:0.1f}%,\n\t\"Status\":\"success\",\n\t\"Temp\":\"{0:0.1f}*\"\n}".format(humidity, temperature)

        number = random.randint(105502001,105502010)
        message = "Student ID={0:9d} Temp={1:0.1f}*  Humidity={2:0.1f}%".format(number,temperature, humidity)
        if temperature > 37.5:
            zSubject = str(number)+ ' Student is burning! '
            zHeader = 'To: ' + zTo + '\n' + 'From: ' + zFrom + '\n' + 'Subject: ' + zSubject            
            zBody = message+"\n"+ str(number) + "Student's body temperature is too high! "
            oSmtp = smtplib.SMTP('smtp.gmail.com',587)
            oSmtp.starttls()
            oSmtp.ehlo()
            oSmtp.login(zUser, zPass)
            oSmtp.sendmail(zFrom, zTo, zHeader + '\n\n' + zBody)
            oSmtp.quit()
            db = pymysql.connect(host = "127.0.0.1",port = 3306, user = "andy", password = "123456", db="class")
            cursor = db.cursor()
            cursor.execute("UPDATE students SET attendance=-1 WHERE name=%s", number)
            db.commit()
            db.close()
        elif temperature < 30:
            message = message + "\nTemperature measurement false."         
        else:
            zSubject = str(number)+' Student is healthy! '
            zHeader = 'To: ' + zTo + '\n' + 'From: ' + zFrom + '\n' + 'Subject:' + zSubject
            zBody = message
            oSmtp = smtplib.SMTP('smtp.gmail.com',587)
            oSmtp.starttls()
            oSmtp.ehlo()
            oSmtp.login(zUser, zPass)
            oSmtp.sendmail(zFrom, zTo, zHeader + '\n\n' + zBody)
            oSmtp.quit()
            db = pymysql.connect(host="127.0.0.1", port=3306, user="andy", password="123456", db="class")
            cursor = db.cursor()
            cursor.execute("UPDATE students SET attendance=1 WHERE name=%s", number)
            db.commit()
            db.close()
        #check if there is no 0 in our table
        db = pymysql.connect(host = "127.0.0.1",port = 3306, user = "andy", password = "123456", db="class")
        cursor = db.cursor()
        cursor.execute("SELECT * FROM students WHERE attendance=0")
        attendance_data = cursor.fetchall()
        attend = 'Attend:\n'
        absent = 'Absent:\n'
        #print(cursor.rowcount)
        if cursor.rowcount == 0:
            cursor.execute("SELECT name,attendance FROM students")
            #db.commit()
            #at_data = cursor.fetchall()
            #attend = 'Attend:\n'
            #absent = 'Absent:\n'
            for i in range(1,10):
                row = cursor.fetchone()
                #print(row)
                db.commit()
                #row = list(row)
                if row[1]==1:
                    tmp = str(row)
                    attend = attend + "\n"+ tmp
                else:
                    tmp = str(row)
                    absent = absent + "\n" + tmp
            zSubject = "Attendance Report"
            zHeader = 'To: ' + zTo + '\n' + 'From: ' + zFrom + '\n' + 'Subject:' + zSubject
            zBody = attend + "\n" + absent
            oSmtp = smtplib.SMTP('smtp.gmail.com',587)
            oSmtp.starttls()
            oSmtp.ehlo()
            oSmtp.login(zUser, zPass)
            oSmtp.sendmail(zFrom, zTo, zHeader + '\n\n' + zBody)
            oSmtp.quit()
            db.commit()
            print(attendance_data)
            db.close()
        # 資料打包,fCnt+1
        lorawan.create(MHDR.CONF_DATA_UP, {'devaddr': devaddr, 'fcnt': fCnt, 'data': list(map(ord, message)) })
        print("fCnt: ",fCnt)
        print("Send Message: ", message)	
        fCnt = fCnt+1
        self.write_payload(lorawan.to_raw())
        self.set_mode(MODE.TX)
	    
    def time_checking(self):
        global RxDone
        # 檢查是否超時
        TIMEOUT = any([self.get_irq_flags()[s] for s in ['rx_timeout']])
        if TIMEOUT:
            print("TIMEOUT!!")
            write_config()
            sys.exit(0)
        elif RxDone:
            print("SUCCESS!!")
            sys.exit(0)
    
    def start(self):
        self.send()
        while True:
            self.time_checking()
            sleep(1)

def binary_array_to_hex(array):
    return ''.join(format(x, '02x') for x in array)

def write_config():
    global devaddr,nwskey,appskey,fCnt
    config = {'devaddr':binary_array_to_hex(devaddr),'nwskey':binary_array_to_hex(nwskey),'appskey':binary_array_to_hex(appskey),'fCnt':fCnt}
    data = json.dumps(config, sort_keys = True, indent = 4, separators=(',', ': '))
    fp = open("config.json","w")
    fp.write(data)
    fp.close()

def read_config():
    global devaddr,nwskey,appskey,fCnt
    config_file = open('config.json')
    parsed_json = json.load(config_file)
    devaddr = list(bytearray.fromhex(parsed_json['devaddr']))
    nwskey = list(bytearray.fromhex(parsed_json['nwskey']))
    appskey = list(bytearray.fromhex(parsed_json['appskey']))
    fCnt = parsed_json['fCnt']
    print("devaddr: ",parsed_json['devaddr'])
    print("nwskey : ",parsed_json['nwskey'])
    print("appskey: ",parsed_json['appskey'],"\n")

# Init
RxDone = False
fCnt = 0
devaddr = []
nwskey = []
appskey = []
read_config()
lora = LoRaWANsend(False)

# Setup
lora.set_mode(MODE.SLEEP)
lora.set_dio_mapping([1,0,0,0,0,0])
lora.set_freq(AS923.FREQ1)
lora.set_spreading_factor(SF.SF7)
lora.set_bw(BW.BW125)
lora.set_pa_config(pa_select=1)
lora.set_pa_config(max_power=0x0F, output_power=0x0E)
lora.set_sync_word(0x34)
lora.set_rx_crc(True)

# Parse command line parameters.
sensor_args = { '11': Adafruit_DHT.DHT11,
                '22': Adafruit_DHT.DHT22,
                '2302': Adafruit_DHT.AM2302 }
sensor = 22
pin = 4
'''
if len(sys.argv) == 3 and sys.argv[1] in sensor_args:
    sensor = sensor_args[sys.argv[1]]
    pin = sys.argv[2]
else:
    print('Usage: sudo ./Adafruit_DHT.py [11|22|2302] <GPIO pin number>')
    print('Example: sudo ./Adafruit_DHT.py 2302 4 - Read from an AM2302 connected to GPIO pin #4')
    sys.exit(1)
'''
humidity, temperature = Adafruit_DHT.read_retry(sensor, pin)

if humidity is not None and temperature is not None:
    print('Temp={0:0.1f}*  Humidity={1:0.1f}% Status=Success'.format(temperature, humidity))
else:
    print('Failed to get reading. Try again!')
    sys.exit(1)

#print(lora)
assert(lora.get_agc_auto_on() == 1)

try:
    print("Sending LoRaWAN message")
    lora.start()
except KeyboardInterrupt:
    sys.stdout.flush()
    print("\nKeyboardInterrupt")
finally:
    sys.stdout.flush()
    lora.set_mode(MODE.SLEEP)
    BOARD.teardown()
    write_config()
